# @vuteq/sso-client-react

Library resmi React dan Next.js untuk **Vuteq Single Sign On (SSO)**. Integrasi memakai pola Backend for Frontend (BFF): OAuth client secret dan token tetap berada di server Next.js, sedangkan browser hanya menerima profil dan hasil otorisasi yang aman.

## Persyaratan

- Node.js 20 atau lebih baru
- Next.js 14, 15, atau 16 dengan App Router
- React 18 atau 19
- OAuth client `CONFIDENTIAL` yang aktif di Vuteq SSO

## Registrasi di SSO

Administrator perlu membuat Application dan OAuth client dengan konfigurasi berikut:

```text
Type:                     CONFIDENTIAL
Redirect URI:             https://aplikasi.vuteq.co.id/auth/callback
Post logout redirect URI: https://aplikasi.vuteq.co.id
Backchannel logout URI:   https://aplikasi.vuteq.co.id/api/auth/backchannel-logout
Scopes:                   openid profile email offline_access api
Resource audience:        audience API aplikasi
```

Untuk development, daftarkan URI localhost yang sesuai, misalnya:

```text
http://localhost:3200/auth/callback
http://localhost:3200
http://localhost:3200/api/auth/backchannel-logout
```

Simpan client secret ketika dibuat atau dirotasi. Secret hanya ditampilkan sekali.

## Instalasi dari GitHub Release

```bash
pnpm add https://github.com/Irfanakbari/sso-sdk/releases/download/react-v0.1.2/vuteq-sso-client-react-0.1.2.tgz
```

Atau tambahkan langsung ke `package.json`:

```json
{
  "dependencies": {
    "@vuteq/sso-client-react": "https://github.com/Irfanakbari/sso-sdk/releases/download/react-v0.1.2/vuteq-sso-client-react-0.1.2.tgz"
  }
}
```

Kemudian jalankan `pnpm install`. Archive release sudah berisi hasil build sehingga aplikasi pengguna tidak perlu membangun source library.

Jika repository bersifat private, download archive memakai GitHub CLI yang sudah terautentikasi lalu pasang file lokalnya:

```bash
gh release download react-v0.1.2 --repo Irfanakbari/sso-sdk --pattern '*.tgz' --dir vendor
pnpm add ./vendor/vuteq-sso-client-react-0.1.2.tgz
```

## Environment

```env
VUTEQ_SSO_BASE_URL=https://sso.vuteq.co.id
VUTEQ_SSO_SECRET=<oauth-client-secret-aplikasi>
```

Jangan memakai awalan `NEXT_PUBLIC_` untuk secret. Base URL SDK adalah issuer publik `https://sso.vuteq.co.id`, bukan `api-sso.vuteq.co.id` dan bukan alamat loopback API SSO.

## Membuat client server

```ts
// src/lib/sso.ts
import "server-only";
import { createNextVuteqSso } from "@vuteq/sso-client-react/next";

export const sso = createNextVuteqSso({
  baseUrl: process.env.VUTEQ_SSO_BASE_URL!,
  secret: process.env.VUTEQ_SSO_SECRET!,
});
```

Jika Next.js berjalan di belakang reverse proxy dan request internal tidak mempertahankan origin publik, aktifkan `trustProxy`:

```ts
export const sso = createNextVuteqSso({
  baseUrl: process.env.VUTEQ_SSO_BASE_URL!,
  secret: process.env.VUTEQ_SSO_SECRET!,
  trustProxy: true,
});
```

Reverse proxy harus menimpa `X-Forwarded-Host` dan `X-Forwarded-Proto` dari client lalu mengirim nilai yang tepercaya.

## Route login, callback, dan logout

```ts
// app/auth/login/route.ts
import { sso } from "@/lib/sso";
export const GET = sso.login;
```

```ts
// app/auth/callback/route.ts
import { sso } from "@/lib/sso";
export const GET = sso.callback;
```

```ts
// app/auth/logout/route.ts
import { sso } from "@/lib/sso";
export const POST = sso.logout;
```

```ts
// app/api/auth/backchannel-logout/route.ts
import { sso } from "@/lib/sso";
export const POST = sso.backchannelLogout;
```

Library menangani Authorization Code Flow, PKCE S256, state, nonce, pertukaran authorization code, validasi access token, refresh token rotation, cookie `HttpOnly`, idle timeout, absolute timeout, dan backchannel logout.

## Endpoint session yang aman

SSO menerbitkan identitas dan role global. Role serta permission bisnis diambil dari database aplikasi berdasarkan claim `sub`.

```ts
// app/api/auth/session/route.ts
import { toClientSession } from "@vuteq/sso-client-react";
import { sso } from "@/lib/sso";
import { authorizationForSsoUser } from "@/lib/authorization";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const session = await sso.session(request);
  const authorization = session
    ? await authorizationForSsoUser(session.profile.sub)
    : undefined;

  return Response.json(toClientSession(session, authorization), {
    headers: { "Cache-Control": "no-store" },
  });
}
```

Contoh resolver milik aplikasi:

```ts
export async function authorizationForSsoUser(ssoUserId: string) {
  const access = await database.userAccess.findUnique({
    where: { ssoUserId },
    include: { roles: true, permissions: true },
  });

  return {
    roles: access?.roles.map((role) => role.name) ?? [],
    permissions: access?.permissions.map((permission) => permission.name) ?? [],
    attributes: { plant: access?.plantCode },
  };
}
```

Gunakan `session.profile.sub` sebagai User ID lintas aplikasi. Username dan email dapat berubah. Ketika token di-refresh, SDK menyelaraskan kembali nama, username, email, dan `email_verified` dari access token terbaru. `toClientSession()` memastikan access token dan ID token tidak dikirim ke browser serta menyediakan `emailVerified`, `mfaVerified`, dan `authenticatedAt` untuk UX aplikasi.

## Provider React

```tsx
// app/providers.tsx
"use client";

import { VuteqSsoProvider } from "@vuteq/sso-client-react/react";

export function Providers({ children }: { children: React.ReactNode }) {
  return <VuteqSsoProvider>{children}</VuteqSsoProvider>;
}
```

```tsx
// app/layout.tsx
import { Providers } from "./providers";

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
```

## Login, logout, dan otorisasi UI

```tsx
"use client";

import {
  LoginButton,
  LogoutButton,
  RequirePermissions,
  RequireRoles,
  SignedIn,
  SignedOut,
  useVuteqSso,
  useVuteqUser,
} from "@vuteq/sso-client-react/react";

export function AccountMenu() {
  const user = useVuteqUser();
  const { loading, hasRole, needsEmailVerification } = useVuteqSso();
  if (loading) return <span>Memeriksa sesi…</span>;

  return (
    <>
      <SignedOut>
        <LoginButton>Masuk dengan Vuteq SSO</LoginButton>
      </SignedOut>

      <SignedIn>
        <span>{user?.name}</span>
        {needsEmailVerification && (
          <a href="https://sso.vuteq.co.id/portal">Verify email in Identity</a>
        )}
        <LogoutButton>Keluar</LogoutButton>
      </SignedIn>

      <RequireRoles roles={["MANAGER", "ADMINISTRATOR"]}>
        <a href="/management">Management</a>
      </RequireRoles>

      <RequirePermissions permissions={["reports.export"]}>
        <button>Export report</button>
      </RequirePermissions>

      {hasRole("AUDITOR") && <a href="/audit">Audit</a>}
    </>
  );
}
```

- `roles` dan `permissions` berasal dari database aplikasi.
- `globalRoles` berasal dari SSO.
- `SUPER_ADMINISTRATOR` melewati pemeriksaan role dan permission lokal.
- `emailVerified`, `mfaVerified`, dan `needsEmailVerification` berasal dari sesi server yang aman.
- Verifikasi email tetap dilakukan di portal Identity; SDK aplikasi tidak memanggil management API Identity.
- Pembatasan komponen React hanya untuk UX. API tetap wajib memeriksa otorisasi di server.

## Memanggil protected API melalui BFF

```ts
// app/api/orders/route.ts
import { sso } from "@/lib/sso";

export async function GET(request: Request) {
  const session = await sso.session(request);
  if (!session) {
    return Response.json(
      { message: "Authentication required" },
      { status: 401 },
    );
  }

  return sso.fetch(request, "https://quality-api.vuteq.co.id/api/v1/orders", {
    cache: "no-store",
  });
}
```

`sso.fetch()` menambahkan access token pada request server-to-server. API tujuan dapat memakai `@vuteq/sso-client-nest` untuk memvalidasi token dan memuat otorisasi lokal.

## Session store production

`MemorySessionStore` cocok untuk development atau satu proses Node.js. Untuk beberapa replica, implementasikan `SessionStore` dengan Redis atau database:

```ts
import type { SessionStore, StoredSession } from "@vuteq/sso-client-react";

export class RedisSessionStore implements SessionStore {
  async get(key: string): Promise<StoredSession | null> {
    throw new Error("Implement Redis read");
  }

  async set(key: string, session: StoredSession): Promise<void> {
    // Simpan dengan TTL dari session.expiresAt.
  }

  async take(key: string): Promise<StoredSession | null> {
    // Gunakan operasi atomik GETDEL.
    throw new Error("Implement atomic GETDEL");
  }

  async delete(key: string): Promise<void> {}

  async deleteMatching(
    clientId: string,
    subject?: string,
    sid?: string,
  ): Promise<number> {
    return 0;
  }

  async withLock<T>(key: string, operation: () => Promise<T>): Promise<T> {
    // Gunakan distributed lock untuk refresh-token rotation.
    return operation();
  }
}
```

```ts
export const sso = createNextVuteqSso({
  baseUrl: process.env.VUTEQ_SSO_BASE_URL!,
  secret: process.env.VUTEQ_SSO_SECRET!,
  store: new RedisSessionStore(),
});
```

`take()` harus atomik dan `withLock()` harus memakai distributed lock.

## Logout

`POST /auth/logout` menghapus session aplikasi dan cookie browser. Pencabutan sesi terpusat dikirim SSO ke `/api/auth/backchannel-logout`. Gunakan POST untuk logout karena handler memeriksa origin request.

## Arsitektur production

```text
Browser
   |
   | cookie aplikasi (HttpOnly)
   v
Next.js aplikasi + @vuteq/sso-client-react
   |                         |
   | OIDC                    | bearer access token
   v                         v
https://sso.vuteq.co.id    API aplikasi
   |
   | internal BFF/reverse proxy milik server SSO
   v
http://127.0.0.1:4100
```

Alamat `127.0.0.1:4100` adalah koneksi internal antara web SSO dan API SSO. Aplikasi klien tidak perlu mengetahui alamat tersebut.

## Troubleshooting

### Callback URL is not registered

Callback harus sama persis dengan Redirect URI di SSO, termasuk HTTPS, hostname, port, dan path.

### The SSO connection secret was rejected

OAuth client atau Application tidak aktif, secret salah, atau secret sudah dirotasi. Perbarui `VUTEQ_SSO_SECRET` pada deployment.

### Sign-in transaction expired

Transaction berlaku sepuluh menit dan hanya dapat digunakan sekali. Pada deployment multi-replica, gunakan shared session store.

### Invalid request origin saat logout

Pastikan form dikirim dari origin aplikasi yang sama. Di belakang reverse proxy, teruskan header host/protocol dengan benar dan aktifkan `trustProxy` bila diperlukan.

### Session hilang setelah restart

Ganti `MemorySessionStore` dengan Redis atau database.

## Checklist deployment

- Gunakan `VUTEQ_SSO_BASE_URL=https://sso.vuteq.co.id`.
- Simpan `VUTEQ_SSO_SECRET` pada secret manager.
- Daftarkan callback, post-logout, dan backchannel logout URI secara persis.
- Gunakan HTTPS pada aplikasi dan API.
- Gunakan shared `SessionStore` untuk beberapa replica.
- Gunakan `sub` sebagai User ID lintas aplikasi.
- Simpan role dan permission bisnis di database aplikasi.
- Jangan mengirim access token atau refresh token ke Client Component.
- Lindungi API meskipun menu sudah disembunyikan oleh React.

## Build dan rilis melalui monorepo

Validasi lokal:

```bash
pnpm --filter @vuteq/sso-client-react test
pnpm --filter @vuteq/sso-client-react typecheck
pnpm build:react
pnpm pack:react
```

Untuk merilis versi baru:

1. Ubah `version` pada `packages/react/package.json`.
2. Commit dan push ke `master`.
3. Buka tab **Actions** di GitHub.
4. Pilih workflow **SDK CI and release**, tekan **Run workflow**, lalu pilih package `react`.
5. Actions menguji seluruh workspace, membuat tag `react-v<version>`, dan mengunggah archive ke GitHub Release.

Folder `dist` dan `artifacts` tidak disimpan pada branch `master`.
