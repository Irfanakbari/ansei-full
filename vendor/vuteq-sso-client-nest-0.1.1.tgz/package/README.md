# @vuteq/sso-client-nest

Library resmi NestJS untuk memvalidasi access token dari **Vuteq Single Sign On (SSO)** dan memasang identitas pengguna pada request. Library menggunakan metadata client dan JWKS yang diambil otomatis dari SSO menggunakan OAuth client secret.

## Persyaratan

- Node.js 20 atau lebih baru
- NestJS 10, 11, atau 12
- OAuth client `CONFIDENTIAL` yang aktif di Vuteq SSO
- Application aktif dengan resource audience API yang unik

## Registrasi di SSO

Administrator perlu membuat:

1. Application untuk sistem yang akan terhubung.
2. Resource audience unik, misalnya `https://quality-api.vuteq.co.id`.
3. OAuth client bertipe `CONFIDENTIAL` untuk Application tersebut.
4. Scope minimal `api`. Tambahkan `openid`, `profile`, `email`, dan `offline_access` jika client juga dipakai oleh frontend.
5. Simpan client secret ketika dibuat atau dirotasi. Secret hanya ditampilkan sekali.

Backend tidak perlu menyimpan `clientId`, issuer, audience, atau alamat JWKS. Library mengambil semuanya dari endpoint bootstrap SSO.

## Instalasi

Tambahkan archive package dari GitHub Release monorepo:

```bash
pnpm add https://github.com/Irfanakbari/sso-sdk/releases/download/nest-v0.1.1/vuteq-sso-client-nest-0.1.1.tgz
```

Atau tulis pada `package.json` aplikasi:

```json
{
  "dependencies": {
    "@vuteq/sso-client-nest": "https://github.com/Irfanakbari/sso-sdk/releases/download/nest-v0.1.1/vuteq-sso-client-nest-0.1.1.tgz"
  }
}
```

Kemudian jalankan `pnpm install`. Archive release sudah berisi hasil build sehingga aplikasi pengguna tidak perlu membangun source library.

Jika repository bersifat private, download archive memakai GitHub CLI yang sudah terautentikasi lalu pasang file lokalnya:

```bash
gh release download nest-v0.1.1 --repo Irfanakbari/sso-sdk --pattern '*.tgz' --dir vendor
pnpm add ./vendor/vuteq-sso-client-nest-0.1.1.tgz
```

```env
VUTEQ_SSO_BASE_URL=https://sso.vuteq.co.id
VUTEQ_SSO_SECRET=<oauth-client-secret-aplikasi>
```

Gunakan issuer publik `https://sso.vuteq.co.id` sebagai base URL. Jangan gunakan `api-sso.vuteq.co.id` atau alamat loopback API SSO.

## Registrasi module

### Konfigurasi langsung

```ts
import { Module } from "@nestjs/common";
import { VuteqSsoModule } from "@vuteq/sso-client-nest";

@Module({
  imports: [
    VuteqSsoModule.forRoot({
      baseUrl: process.env.VUTEQ_SSO_BASE_URL!,
      secret: process.env.VUTEQ_SSO_SECRET!,
    }),
  ],
})
export class AppModule {}
```

Module bersifat global secara default dan mendaftarkan `VuteqSsoGuard` sebagai `APP_GUARD`. Semua endpoint membutuhkan bearer token kecuali endpoint dengan `@Public()`.

### Menggunakan ConfigService

```ts
import { Module } from "@nestjs/common";
import { ConfigModule, ConfigService } from "@nestjs/config";
import { VuteqSsoModule } from "@vuteq/sso-client-nest";

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    VuteqSsoModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (config: ConfigService) => ({
        baseUrl: config.getOrThrow<string>("VUTEQ_SSO_BASE_URL"),
        secret: config.getOrThrow<string>("VUTEQ_SSO_SECRET"),
      }),
    }),
  ],
})
export class AppModule {}
```

## Endpoint publik dan terautentikasi

```ts
import { Controller, Get } from "@nestjs/common";
import {
  CurrentAuth,
  CurrentClaims,
  CurrentToken,
  CurrentUser,
  Public,
  type VuteqAccessClaims,
  type VuteqAuthContext,
  type VuteqUser,
} from "@vuteq/sso-client-nest";

@Controller("api/v1/orders")
export class OrdersController {
  @Public()
  @Get("health")
  health() {
    return { status: "ok" };
  }

  @Get("me")
  me(
    @CurrentUser() user: VuteqUser,
    @CurrentClaims() claims: VuteqAccessClaims,
    @CurrentToken() token: string,
    @CurrentAuth() auth: VuteqAuthContext,
  ) {
    return {
      userId: user.id,
      username: user.username,
      email: user.email,
      globalRoles: user.globalRoles,
      clientId: auth.clientId,
      grantId: auth.grantId,
      emailVerified: user.emailVerified,
      mfaVerified: auth.mfaVerified,
      authenticatedAt: auth.authenticatedAt,
    };
  }

  @Get("mine")
  mine(@CurrentUser("id") userId: string) {
    return { userId };
  }
}
```

`user.id` berasal dari claim OIDC `sub`. Nilai ini merupakan User ID stabil dan harus menjadi kunci relasi pada database aplikasi. Username dan email dapat berubah sehingga tidak boleh dipakai sebagai foreign key.

`user.emailVerified` mengikuti claim terbaru pada access token. Gunakan status ini untuk UX aplikasi saja; pengiriman tautan verifikasi tetap dilakukan oleh portal Identity atau administrator Identity, bukan oleh resource API aplikasi. `auth.mfaVerified` dan `auth.authenticatedAt` tersedia untuk kebijakan step-up lokal.

## Role dan permission aplikasi

SSO hanya menerbitkan role global organisasi, misalnya `SUPER_ADMINISTRATOR`. Role dan permission bisnis tetap disimpan oleh setiap aplikasi.

Gunakan `resolveAuthorization` untuk mengambil otorisasi lokal berdasarkan User ID SSO:

```ts
import { Module } from "@nestjs/common";
import { VuteqSsoModule } from "@vuteq/sso-client-nest";
import { AuthorizationModule } from "./authorization/authorization.module";
import { AuthorizationService } from "./authorization/authorization.service";

@Module({
  imports: [
    AuthorizationModule,
    VuteqSsoModule.forRootAsync({
      imports: [AuthorizationModule],
      inject: [AuthorizationService],
      useFactory: (authorization: AuthorizationService) => ({
        baseUrl: process.env.VUTEQ_SSO_BASE_URL!,
        secret: process.env.VUTEQ_SSO_SECRET!,
        resolveAuthorization: ({ id }) => authorization.forSsoUser(id),
      }),
    }),
  ],
})
export class AppModule {}
```

Resolver mengembalikan data milik aplikasi:

```ts
async forSsoUser(ssoUserId: string) {
  const assignment = await this.database.userAccess.findUnique({
    where: { ssoUserId },
    include: { roles: true, permissions: true },
  });

  return {
    roles: assignment?.roles.map((role) => role.name) ?? [],
    permissions:
      assignment?.permissions.map((permission) => permission.name) ?? [],
    attributes: { plant: assignment?.plantCode },
  };
}
```

Terapkan otorisasi pada controller:

```ts
import { GlobalRoles, Permissions, Roles } from '@vuteq/sso-client-nest';

@Get()
@Roles('MANAGER', 'ADMINISTRATOR')
@Permissions('orders.read')
list() {
  return this.orders.list();
}

@Get('platform-status')
@GlobalRoles('SUPER_ADMINISTRATOR')
platformStatus() {
  return { status: 'ok' };
}
```

- `@Roles()` menerima akses jika salah satu role lokal cocok.
- `@Permissions()` mengharuskan semua permission lokal yang disebutkan.
- `@GlobalRoles()` memeriksa role organisasi yang diterbitkan SSO.
- `SUPER_ADMINISTRATOR` melewati pemeriksaan role dan permission lokal.

## Menggunakan service secara langsung

```ts
import { Injectable } from "@nestjs/common";
import { VuteqSsoService } from "@vuteq/sso-client-nest";

@Injectable()
export class TokenService {
  constructor(private readonly sso: VuteqSsoService) {}

  authenticate(authorizationHeader: string) {
    return this.sso.authenticate(authorizationHeader);
  }

  verify(accessToken: string) {
    return this.sso.verifyToken(accessToken);
  }

  metadata() {
    return this.sso.metadata();
  }
}
```

## Cara frontend mengirim token

Frontend atau BFF mengirim access token ke API:

```http
Authorization: Bearer <access-token>
```

Jangan menerima ID token sebagai bearer token API. Library memverifikasi access token dengan signature RS256, issuer, resource audience, client ID, masa berlaku, dan claim grant.

## Arsitektur production

```text
Browser / BFF aplikasi
        |
        | OIDC + HTTPS
        v
https://sso.vuteq.co.id
        |
        | internal reverse proxy milik SSO
        v
http://127.0.0.1:4100

Browser / BFF aplikasi
        |
        | Bearer access token
        v
API aplikasi + @vuteq/sso-client-nest
```

Alamat `127.0.0.1:4100` hanya digunakan oleh frontend/BFF server SSO pada host yang sama. Aplikasi pemakai SDK tidak perlu mengetahui alamat tersebut.

## Penanganan error

- Token hilang, tidak valid, atau kedaluwarsa menghasilkan HTTP `401`.
- Role atau permission tidak memenuhi syarat menghasilkan HTTP `403`.
- Secret salah atau sudah dirotasi menyebabkan metadata bootstrap ditolak.
- Audience yang berbeda dari Application resource menyebabkan token ditolak.

## Checklist deployment

- Gunakan `VUTEQ_SSO_BASE_URL=https://sso.vuteq.co.id`.
- Simpan `VUTEQ_SSO_SECRET` pada secret manager, bukan repository.
- Gunakan HTTPS pada API aplikasi.
- Daftarkan audience API secara persis di SSO.
- Gunakan `sub` sebagai ID pengguna lintas aplikasi.
- Simpan role dan permission bisnis di database aplikasi.
- Perbarui secret deployment setelah secret OAuth client dirotasi.

## Build dan rilis melalui monorepo

```bash
pnpm --filter @vuteq/sso-client-nest test
pnpm --filter @vuteq/sso-client-nest typecheck
pnpm build:nest
pnpm pack:nest
```

Untuk merilis versi baru:

1. Ubah `version` pada `packages/nest/package.json`.
2. Commit dan push perubahan ke `master`.
3. Buka tab **Actions** di GitHub.
4. Pilih workflow **SDK CI and release**, tekan **Run workflow**, lalu pilih package `nest`.
5. Actions menguji seluruh workspace, membuat tag `nest-v<version>`, dan mengunggah archive ke GitHub Release.

Folder `dist` dan `artifacts` tidak disimpan pada branch `master`.
